import { Component, OnInit, ViewChild } from "@angular/core";
import { MatTableDataSource, MatSort, MatPaginator } from "@angular/material";
import { Router, ActivatedRoute } from "@angular/router";
import { TranslateService } from "@ngx-translate/core";
import { Location } from "@angular/common";
import { ConventionService } from "../../../utils/convention.service";
import { NotificationService } from "../../../shared/notification.service";
@Component({
	selector: "kt-list-convention",
	templateUrl: "./list-convention.component.html",
	styleUrls: ["./list-convention.component.scss"],
})
export class ListConventionComponent implements OnInit {
	id: number;
	url: string;
	// ============================================
	// Presentation de datasource
	// ============================================

	displayedColumns: string[] = ["objet", "dateSignature", "dateEffet", "dateFin", "typeConvention", "statutConvention", "actions"];
	// ============================================
	// Declarations
	// ============================================
	dataSource = new MatTableDataSource<any>();
	isLoadingResults = true;
	// ============================================
	// Controles pagination
	// ============================================
	@ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
	@ViewChild(MatSort, { static: true }) sort: MatSort;
	// ============================================
	// Constructeur
	// ============================================
	constructor(private conventionService: ConventionService, private translate: TranslateService, private router: Router, private location: Location, private route: ActivatedRoute, private notification: NotificationService) {
		this.getConvention();
		console.log("kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk", this.getConvention());
	}

	ngOnInit() {}
	// ============================================
	// Recuperer tous les association
	// ============================================
	public getConvention() {
		// this.id = this.route.snapshot.params['id'];
		// console.log('id :' + this.id);
		this.conventionService.getAllObject("/convention/index").subscribe(
			(data) => {
				this.dataSource = new MatTableDataSource(data);
				this.isLoadingResults = false;
				this.paginator._intl.itemsPerPageLabel = this.translate.instant("PAGES.GENERAL.ITEMS_PER_PAGE_LABEL");
				this.paginator._intl.nextPageLabel = this.translate.instant("PAGES.GENERAL.NEXT_PAGE_LABEL");
				this.paginator._intl.previousPageLabel = this.translate.instant("PAGES.GENERAL.PREVIOUS_PAGE_LABEL");
				this.paginator._intl.lastPageLabel = this.translate.instant("PAGES.GENERAL.LAST_PAGE_LABEL");
				this.paginator._intl.firstPageLabel = this.translate.instant("PAGES.GENERAL.FIRST_PAGE_LABEL");
				this.dataSource.paginator = this.paginator;
				this.dataSource.sort = this.sort;
			},
			(err) => {
				console.log(err);
				this.isLoadingResults = false;
			}
		);
	}

	// ============================================
	// Filter de recherche
	// ============================================
	applyFilter(filterValue: string) {
		this.dataSource.filter = filterValue.trim().toLowerCase();

		if (this.dataSource.paginator) {
			this.dataSource.paginator.firstPage();
		}
	}

	// ============================================
	// Methode de suppression des convention
	// ============================================
	deleteConvention(id: number): void {
		if (confirm(this.translate.instant("PAGES.GENERAL.MSG_DELETED"))) {
			this.conventionService.deleteConvention("/convention/delete/", id).subscribe((data) => {
				console.log("getId :" + id);
				this.getConvention();
			});
			this.conventionService.deletefiles("/PjConvention/ByIdConvention/", id).subscribe((data) => {
				console.log("File deleted : " + id);
			});
			this.notification.warn(this.translate.instant("PAGES.GENERAL.MSG_DEL_CONFIRMED"));
		}
	}
	// ============================================
	// Methode d'insertion des convention
	// ============================================
	addConvention(): void {
		this.router.navigate(["convention/add-convention"]);
	}
	showConvention(id: number): void {
		this.router.navigate(["conventions/show-convention/" + id]);
	}

	/* addConvention(){
		this.id = this.route.snapshot.params['id'];
		window.localStorage.removeItem("assocId");
		window.localStorage.setItem("assocId",""+this.id);
		this.router.navigate(["convention/add-convention"]);
	} */

	editConvention(id: number): void {
		this.router.navigate(["conventions/edit-convention/" + id]);
	}
}
