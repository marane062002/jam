import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { TranslateService } from "@ngx-translate/core";
import { finalize, first } from "rxjs/operators";
import { NotificationService } from "../../../shared/notification.service";
import { ConventionService } from "../../../utils/convention.service";
import { SpinnerService } from "../../../utils/spinner.service";
import { Location } from "@angular/common";
import { MatSelectChange } from "@angular/material";

@Component({
	selector: "kt-edit-convention",
	templateUrl: "./edit-convention.component.html",
	styleUrls: ["./edit-convention.component.scss"],
})
export class EditConventionComponent implements OnInit {
	// ============================================
	// Declarations
	// ============================================
	id: any;
	isVisibleNature: boolean;
	listArrondissements: any[];
	loading = false;
	submitted = false;
	addForm: FormGroup;
	addFileForm1: FormGroup;
	addFileForm2: FormGroup;
	addFileForm3: FormGroup;
	addFileForm4: FormGroup;
	addFileForm5: FormGroup;
	public uploadFiles1: Array<File>;
	public uploadFiles2: Array<File>;
	public uploadFiles3: Array<File>;
	public uploadFiles4: Array<File>;
	public uploadFiles5: Array<File>;
	// Listes
	arrondissements: any;
	statuts: any;
	typeActivites: any;
	villes: any;
	annexesAdmin: any;

	constructor(private service: ConventionService, private router: Router, private route: ActivatedRoute, private fb: FormBuilder, private location: Location, private notification: NotificationService, private translate: TranslateService, private spinnerService: SpinnerService) {
		this.getData();
		this.formBuilder();
		this.getArrondissements();
	}

	ngOnInit() {
		// document.getElementById("autreAnnxe").style.display = "none";
		// document.getElementById("autreSpecialite").style.display = "none";
		this.fileBuilder();
		var spinnerRef = this.spinnerService.start(this.translate.instant("PAGES.GENERAL.LOADING")); // start spinner
		this.id = this.route.snapshot.params["id"];
		this.service
			.getObjectById("/convention/show/", this.id)
			.pipe(
				finalize(() => {
					this.spinnerService.stop(spinnerRef); // stop spinner
				})
			)
			.subscribe((data) => {
				console.log("Fetch data  : " + JSON.stringify(data, null, 2));

				this.addForm.patchValue({ ...data });
			});
	}
	suiviExecution: string[] = ["Oui", "Non"];
	suiviRapportsList: any[] = [];
	onchangeRapportfinancier(event: any) {
		if (event == "Oui") {
			this.suiviRapportsList.push("FINANCIERE");
		}
		if (event == "Non") {
			if (this.suiviRapportsList.includes("FINANCIERE")) {
				const index = this.suiviRapportsList.indexOf("FINANCIERE");
				if (index !== -1) {
					this.suiviRapportsList.splice(index, 1);
				}
			}
		}
	}

	localChanged(event: any) {
		console.log(event);
		console.log(event.value);
		if (event.value == "المقاطعة") {
			this.isVisibleNature = true;
			console.log("true");
		} else {
			this.isVisibleNature = false;
			console.log("false");
		}
	}
	onchangeRapportLitteraire(event: any) {
		if (event == "Oui") {
			this.suiviRapportsList.push("LITTERALE");
		}
		if (event == "Non") {
			if (this.suiviRapportsList.includes("LITTERALE")) {
				const index = this.suiviRapportsList.indexOf("LITTERALE");
				if (index !== -1) {
					this.suiviRapportsList.splice(index, 1);
				}
			}
		}
	}
	onchangeRapportCommission(event: any) {
		if (event == "Oui") {
			this.suiviRapportsList.push("COMMISION");
		}
		if (event == "Non") {
			if (this.suiviRapportsList.includes("COMMISION")) {
				const index = this.suiviRapportsList.indexOf("COMMISION");
				if (index !== -1) {
					this.suiviRapportsList.splice(index, 1);
				}
			}
		}
	}
	valueAssociation: any = "";
	nomAssociation: string;

	campareWithId(p1: any, p2: any): boolean {
		if (p1 && p2) {
			return p1.id === p2.id;
		}
		return false;
	}
	// ============================================
	// OnSubmit
	// ============================================
	onSubmit() {
		//console.log("Association :: " + JSON.stringify(this.addForm.value,null, 2))
		const controls = this.addForm.controls;
		/** check form */
		if (this.addForm.invalid) {
			Object.keys(controls).forEach((controlName) => controls[controlName].markAsTouched());
			return;
		}

		this.loading = true;

		this.addConvention();
	}
	// ============================================
	// Ajouter une association
	// ============================================
	getArrondissements() {
		this.service.getArrondissements().subscribe(
			(data) => {
				this.listArrondissements = data;
			},
			(err) => {
				console.log(err);
			}
		);
	}
	addConvention() {
		this.addForm.value.nomAssociation = this.nomAssociation;
		console.log(JSON.stringify(this.addForm.value, null, 4));
		this.submitted = true;
		this.addForm.value.nomAssociation = this.nomAssociation;
		this.addForm.value.suiveeExec = this.suiviRapportsList;
		console.log(this.addForm.value);

		console.log("Submit : " + JSON.stringify(this.addForm.value, null, 2));

		this.submitted = true;
		if (this.addForm.invalid) {
			return;
		}
		this.service
			.updateObject("/convention/edit/", this.addForm.value)
			.pipe(first())
			.subscribe(
				(data) => {
					this.router.navigate(["convention/list-convention"]);
					this.notification.warn(this.translate.instant("PAGES.GENERAL.MSG_UPDATE_CONFIRMED"));
					window.localStorage.removeItem("associationId");
					window.localStorage.setItem("associationId", data.toString());
				},
				(error) => {
					alert(error);
				}
			);
	}

	// ============================================
	// Charger les elements du fourmulaire
	// ============================================
	formBuilder() {
		let assocId = window.localStorage.getItem("assocId");
		this.addForm = this.fb.group({
			id: [""],
			test: [""],
			nombreRenouvelle: [""],
			objetConvention: [""],
			numSubvention: [""],
			anneeSingConvention: [""],
			anneeAcquisition: [""],
			nomAssociation: [""],
			champActivite: [""],
			natureActivite: [""],
			activite_de_rayonnement: [""],
			cible: [""],
			local: [""],
			arrondissement: [""],
			natureSubvention: [""],
			montantDemande: [""],
			suiveeExec: [""],
			suiveeExec1: [""],
			suiveeExec2: [""],
			renouv: [""],
		});
	}
	// ============================================
	// Files upload
	// ============================================
	fileBuilder() {
		this.addFileForm1 = this.fb.group({
			statut_file: [],
		});
		this.addFileForm2 = this.fb.group({
			pvConstitution_file: [],
		});
		this.addFileForm3 = this.fb.group({
			dernierPv_file: [],
		});
		this.addFileForm4 = this.fb.group({
			recipisse_file: [],
		});
		this.addFileForm5 = this.fb.group({
			membreBureau_file: [],
		});
	}
	// ============================================
	// Charger les liste externe
	// ============================================
	disabled: boolean = true;
	listAssociations: any[];
	getData() {
		this.disabled = false;
		this.service.getAssociation().subscribe(
			(data) => {
				this.listAssociations = data;
			},
			(err) => {
				console.log(err);
			}
		);
		this.service.getData().subscribe(
			(data) => {
				this.statuts = data[0];
				this.typeActivites = data[1];
				this.villes = data[2];
				//this.annexesAdmin = data[3];
				//console.log(data[1]);
			},
			(err) => {
				console.log(err);
			}
		);
	}
	// ============================================
	// OnReset
	// ============================================
	onReset() {
		this.submitted = false;
		this.addForm.reset();
	}
	// =====================================
	// back to list
	// =====================================
	back() {
		this.router.navigate(["convention/list-convention"]);
	}
	// ============================================
	// Upload file event fileChangePjStatut
	// ============================================
	fileChangePjStatut(event) {
		this.uploadFiles1 = event.target.files;
		if (event.target.files.length > 0) {
			console.log("target statut : " + event.target.files.length);
			const file = event.target.files[0];
			this.addFileForm1.patchValue(this.uploadFiles1);
			console.log("OK get pj statut");
		}
	}
	// ============================================
	// Upload file event fileChangePjPvConstitution
	// ============================================
	fileChangePjPvConstitution(event) {
		this.uploadFiles2 = event.target.files;
		if (event.target.files.length > 0) {
			console.log("target constitution: " + event.target.files.length);
			const file = event.target.files[0];
			this.addFileForm2.patchValue(this.uploadFiles2);
			console.log("OK get pj pv constitution");
		}
	}
	// ============================================
	// Upload file event fileChangePjDernierPv
	// ============================================
	fileChangePjDernierPv(event) {
		this.uploadFiles3 = event.target.files;
		if (event.target.files.length > 0) {
			console.log("target dernier pv: " + event.target.files.length);
			const file = event.target.files[0];
			this.addFileForm3.patchValue(this.uploadFiles3);
			console.log("OK get pj dernier pv");
		}
	}
	// ============================================
	// Upload file event fileChangePjRecipisse
	// ============================================
	fileChangePjRecipisse(event) {
		this.uploadFiles4 = event.target.files;
		if (event.target.files.length > 0) {
			console.log("target recipisse: " + event.target.files.length);
			const file = event.target.files[0];
			this.addFileForm4.patchValue(this.uploadFiles4);
			console.log("OK get pj recipisse");
		}
	}
	// ============================================
	// Upload file event fileChangePjMembreBureau
	// ============================================
	fileChangePjMembreBureau(event) {
		this.uploadFiles5 = event.target.files;
		if (event.target.files.length > 0) {
			console.log("target membre bureau: " + event.target.files.length);
			const file = event.target.files[0];
			this.addFileForm5.patchValue(this.uploadFiles5);
			console.log("OK get pj membre bureau :");
		}
	}
	// ============================================

	// ============================================
	// annexeChanged events
	// ============================================
	annexeChanged() {
		let annexeAdm = this.addForm.get("annexeAdministratif").value;
		console.log("Id annexe: " + annexeAdm.id);
		this.addForm.get("autreAnnxe").reset();
		if (annexeAdm.id == 31) {
			document.getElementById("autreAnnxe").style.display = "inline";
			this.addForm.get("autreAnnexe").setValue(null);
		} else {
			document.getElementById("autreAnnxe").style.display = "none";
			this.addForm.get("autreAnnexe").setValue(null);
		}
	}
	// ============================================
	// type changed events
	// ============================================
	typeChanged(event: MatSelectChange) {
		this.valueAssociation = event.value.id;
		this.nomAssociation = event.value.nom;
	}
	// ============================================
	// villeChanged events
	// ============================================
	villeChanged(event: any) {
		let ville = this.addForm.get("villeActivite").value;
		document.getElementById("autreAnnxe").style.display = "none";
		if (ville.id == "1") {
			this.addForm.get("communeActivite").enable();
			this.addForm.get("communeActivite").reset();
			this.addForm.get("annexeAdministratif").enable();
			this.addForm.get("annexeAdministratif").reset();
			this.addForm.get("autreAnnexe").reset();
			// this.addForm.get("communeActivite").setValidators(Validators.required);
			// this.addForm.get("annexeAdministratif").setValidators(Validators.required);
		} else {
			this.addForm.get("communeActivite").disable();
			this.addForm.get("communeActivite").reset();
			this.addForm.get("annexeAdministratif").disable();
			this.addForm.get("annexeAdministratif").reset();
			this.addForm.get("autreAnnexe").reset();
			// this.addForm.get("communeActivite").setValidators(null);
			// this.addForm.get("annexeAdministratif").setValidators(null);
		}
		// this.addForm.get('communeActivite').updateValueAndValidity();
		// this.addForm.get('annexeAdministratif').updateValueAndValidity();
	}
	// ============================================
	// ArrondissementChanged events

	// ============================================================
	// field validation
	// ============================================================
	/**
	 * Checking control validation
	 *
	 * @param controlName: string => Equals to formControlName
	 * @param validationType: string => Equals to valitors name
	 */
	isControlHasError(controlName: string, validationType: string): boolean {
		const control = this.addForm.controls[controlName];
		if (!control) {
			return false;
		}

		const result = control.hasError(validationType) && (control.dirty || control.touched);
		return result;
	}
}
