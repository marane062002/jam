import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-convention',
  templateUrl: './convention.component.html',
  styleUrls: ['./convention.component.scss']
})
export class ConventionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
