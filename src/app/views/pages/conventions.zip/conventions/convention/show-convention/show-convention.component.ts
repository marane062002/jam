import { environment } from "./../../../../../../environments/environment";
import { Component, OnInit } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";
import { ConventionService } from "../../../utils/convention.service";
import { FilesUtilsService } from "../../../utils/files-utils.service";
import { Observable } from "rxjs";

@Component({
	selector: "kt-show-convention",
	templateUrl: "./show-convention.component.html",
	styleUrls: ["./show-convention.component.scss"],
})
export class ShowConventionComponent implements OnInit {
	id: number;
	details: any;
	pjs;
	files: Observable<any>;
	start: boolean = true;
	history: boolean = false;
	constructor(private service: ConventionService, private router: Router, private route: ActivatedRoute, private filesUtil: FilesUtilsService) {
		this.id = this.route.snapshot.params["id"];
		if (!this.id) {
			alert("Invalid action.");
			//this.router.navigate(["list-courriers-entrants"]);
			return;
		}

		setTimeout(() => {
			if (this.id != null) this.files = this.service.getByIdFiles(this.id);
			this.start = false;
		}, 1000);
	}

	ngOnInit() {
		this.id = this.route.snapshot.params["id"];

		this.service.getObjectById("/convention/show/", this.id).subscribe(
			(data) => {
				console.log(data);
				this.details = data;
			},
			(error) => console.log(error)
		);
		// this.service.getByIdFiles(this.id).subscribe(m => {
		// 	this.pjs=m;
		// 	console.log("file log :" + this.pjs.id)
		// });
	}

	// ============================================================
	// get file name
	// ============================================================
	FileName(file) {
		return this.filesUtil.getFileName(file);
	}
	// ============================================================
	// get file extension & icons
	// ============================================================
	FileExtension(file) {
		return this.filesUtil.getExtensionFile(file);
	}
	// =================================================================
	// Download file from server
	// =================================================================
	onClickPjName(e, id) {
		//console.log("You clicked: " + e);
		var r = e.substring(0, e.length - 4);
		console.log(r);
		window.open(environment.API_ALFRESCO_URL + "/PjConvention/" + r);
	}
	// =====================================
	// back to list
	// =====================================
	back() {
		this.router.navigate(["convention/list-convention/"]);
	}
	// ============================================
	// Methode de modification
	// ============================================
	editConvention(id: number) {
		this.id = this.route.snapshot.params["id"];
		this.router.navigate(["conventions/edit-convention/" + this.id]);
	}

	showHitory() {
		this.history = !this.history;
	}
}
